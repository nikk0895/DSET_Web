function toggleMenu() {
  document.getElementById("mobile-menu").classList.toggle("open");
}
